%{
    Code written by Zeynep Melis SUAR
    December 2017
%}
function [a] = contrad(R,d)
    a = sqrt(R.*d);
end